"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { cn } from "@/lib/utils";
import { useSettingsStore, useAuthStore, usePlatformStore } from "@/lib/store";
import { B2B_SIDEBAR_NAV, B2B_SIDEBAR_BOTTOM, APP_NAME } from "@/config/app";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import {
  PanelLeftClose,
  PanelLeftOpen,
  Wallet,
  LogOut,
  RefreshCw,
} from "lucide-react";
import Image from "next/image";
import { useEffect, useState } from "react";
import { agentApi, unwrap } from "@/lib/api/services";

export function B2BSidebar() {
  const pathname = usePathname();
  const router = useRouter();
  const { sidebarOpen, toggleSidebar, setSidebarOpen } = useSettingsStore();
  const { ps, fetchIfStale } = usePlatformStore();
  useEffect(() => {
    fetchIfStale();
  }, []);
  const platformName = ps.platformName || APP_NAME;
  const { user, clearAuth } = useAuthStore();
  const [isMobile, setIsMobile] = useState(false);

  // ── Live wallet balance — fetch fresh from API, not from stale store ──
  const [liveBalance, setLiveBalance] = useState<number | null>(null);
  const [balLoading, setBalLoading] = useState(false);

  const fetchBalance = async () => {
    setBalLoading(true);
    try {
      const res = await agentApi.getWallet();
      const d = unwrap(res) as any;
      const bal =
        typeof d === "number" ? d : (d?.balance ?? d?.walletBalance ?? 0);
      setLiveBalance(bal);
    } catch {
      // fallback to store value
      setLiveBalance(user?.walletBalance ?? 0);
    } finally {
      setBalLoading(false);
    }
  };

  useEffect(() => {
    if (user) fetchBalance();
  }, [user]);

  useEffect(() => {
    const handleResize = () => {
      const mobile = window.innerWidth < 768;
      setIsMobile(mobile);
      if (mobile) setSidebarOpen(false);
    };

    handleResize();
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, [setSidebarOpen]);

  const displayBalance =
    liveBalance !== null ? liveBalance : (user?.walletBalance ?? 0);
  const showLabels = isMobile ? true : sidebarOpen;

  const handleNavClick = () => {
    if (isMobile) setSidebarOpen(false);
  };

  const handleLogout = () => {
    clearAuth();
    setSidebarOpen(false);
    router.push("/b2b/login");
  };

  return (
    <TooltipProvider delayDuration={0}>
      {isMobile && sidebarOpen && (
        <button
          type="button"
          aria-label="Close sidebar overlay"
          className="fixed inset-0 z-30 bg-foreground/35 backdrop-blur-[1px] md:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      <aside
        className={cn(
          "fixed left-0 top-0 z-40 h-screen bg-card border-r border-border transition-all duration-300 flex flex-col",
          "w-72 md:w-64",
          isMobile
            ? sidebarOpen
              ? "translate-x-0"
              : "-translate-x-full"
            : "translate-x-0",
          !isMobile && !sidebarOpen && "md:w-[70px]",
        )}
      >
        {/* Logo */}
        <div className="flex items-center h-16 border-b border-border px-4 flex-shrink-0">
          <div className="flex items-center gap-2.5 min-w-0 flex-1">
            <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl overflow-hidden bg-white border border-border">
              <Image
                src="/logo.jpg"
                alt={platformName}
                width={36}
                height={36}
                className="h-9 w-9 object-contain"
              />
            </div>
            {showLabels && (
              <div>
                <p className="font-bold text-sm leading-none">{platformName}</p>
                <p className="text-[10px] text-muted-foreground leading-none mt-0.5">
                  Agent Portal
                </p>
              </div>
            )}
          </div>
          <button
            onClick={toggleSidebar}
            className="p-1.5 rounded-md hover:bg-muted text-muted-foreground transition-colors flex-shrink-0"
          >
            {sidebarOpen ? (
              <PanelLeftClose className="h-4 w-4" />
            ) : (
              <PanelLeftOpen className="h-4 w-4" />
            )}
          </button>
        </div>

        {/* Navigation */}
        <nav className="flex-1 overflow-y-auto p-3 space-y-0.5">
          {B2B_SIDEBAR_NAV.map((item) => {
            const isActive =
              pathname === item.href || pathname.startsWith(item.href + "/");
            const Icon = item.icon!;
            return (
              <Tooltip key={item.href}>
                <TooltipTrigger asChild>
                  <Link
                    href={item.href}
                    onClick={handleNavClick}
                    className={cn(
                      "flex items-center gap-3 rounded-xl px-3 py-2.5 transition-all font-medium text-sm",
                      isActive
                        ? "bg-[#208dcb] text-white shadow-sm shadow-[#208dcb]/20"
                        : "text-muted-foreground hover:text-foreground hover:bg-muted/60",
                    )}
                  >
                    <Icon className="h-4 w-4 shrink-0" />
                    {showLabels && (
                      <span className="flex-1 truncate">{item.label}</span>
                    )}
                  </Link>
                </TooltipTrigger>
                {!showLabels && (
                  <TooltipContent side="right">{item.label}</TooltipContent>
                )}
              </Tooltip>
            );
          })}
        </nav>

        {/* Wallet Balance — live from API */}
        {showLabels && (
          <div className="mx-3 mb-2 p-3 bg-primary/8 rounded-xl border border-primary/20">
            <div className="flex items-center justify-between mb-1">
              <div className="flex items-center gap-2 text-primary">
                <Wallet className="h-3.5 w-3.5" />
                <span className="text-xs font-semibold">Wallet Balance</span>
              </div>
              <button
                onClick={fetchBalance}
                disabled={balLoading}
                className="p-1 rounded-md hover:bg-primary/10 text-primary/60 hover:text-primary transition-colors"
              >
                <RefreshCw
                  className={cn("h-3 w-3", balLoading && "animate-spin")}
                />
              </button>
            </div>
            <p className="text-lg font-bold text-primary">
              {balLoading ? "—" : `₹${displayBalance.toLocaleString("en-IN")}`}
            </p>
            <Link
              href="/b2b/wallet"
              className="text-[10px] text-primary/70 hover:text-primary transition-colors underline-offset-2 hover:underline"
            >
              View transactions →
            </Link>
          </div>
        )}

        {/* Bottom Nav + Logout */}
        <div className="p-3 border-t border-border space-y-0.5">
          {B2B_SIDEBAR_BOTTOM.map((item) => {
            const isActive = pathname === item.href;
            const Icon = item.icon!;
            return (
              <Tooltip key={item.href}>
                <TooltipTrigger asChild>
                  <Link
                    href={item.href}
                    onClick={handleNavClick}
                    className={cn(
                      "flex items-center gap-3 rounded-xl px-3 py-2.5 transition-all font-medium text-sm",
                      isActive
                        ? "bg-primary text-primary-foreground"
                        : "text-muted-foreground hover:text-foreground hover:bg-muted/60",
                    )}
                  >
                    <Icon className="h-4 w-4 shrink-0" />
                    {showLabels && (
                      <span className="truncate">{item.label}</span>
                    )}
                  </Link>
                </TooltipTrigger>
                {!showLabels && (
                  <TooltipContent side="right">{item.label}</TooltipContent>
                )}
              </Tooltip>
            );
          })}

          {/* Logout */}
          <Tooltip>
            <TooltipTrigger asChild>
              <button
                onClick={handleLogout}
                className="w-full flex items-center gap-3 rounded-xl px-3 py-2.5 transition-all font-medium text-sm text-muted-foreground hover:text-red-500 hover:bg-red-500/10"
              >
                <LogOut className="h-4 w-4 shrink-0" />
                {showLabels && <span className="truncate">Logout</span>}
              </button>
            </TooltipTrigger>
            {!showLabels && (
              <TooltipContent side="right">Logout</TooltipContent>
            )}
          </Tooltip>

          {/* Agent info */}
          {showLabels && user && (
            <div className="mt-2 px-3 py-2 rounded-xl bg-muted/50">
              <p className="text-xs font-semibold truncate">
                {user.name || user.agencyName || "Agent"}
              </p>
              <p className="text-[10px] text-muted-foreground truncate">
                {user.email}
              </p>
              {user.agentId && (
                <p className="text-[10px] font-mono font-bold text-primary/80 tracking-wide">
                  {user.agentId}
                </p>
              )}
            </div>
          )}
        </div>
      </aside>
    </TooltipProvider>
  );
}
