import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";

export function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl;
  const token = request.cookies.get("auth_token")?.value;

  // Public B2B routes — always allow
  const publicRoutes = [
    "/b2b/login",
    "/b2b/register",
    "/b2b/kyc",
    "/b2b/forgot-password",
    "/b2b/reset-password",
  ];

  if (pathname === "/") {
    const url = new URL(token ? "/b2b/dashboard" : "/b2b/login", request.url);
    return NextResponse.redirect(url);
  }

  if (pathname.startsWith("/_next") || pathname.startsWith("/favicon")) {
    return NextResponse.next();
  }

  if (publicRoutes.some((p) => pathname === p || pathname.startsWith(p + "/"))) {
    return NextResponse.next();
  }

  // All other routes require auth
  if (!token) {
    const url = new URL("/b2b/login", request.url);
    url.searchParams.set("redirect", pathname);
    return NextResponse.redirect(url);
  }

  return NextResponse.next();
}

export const config = {
  matcher: ["/((?!_next/static|_next/image|favicon.ico|public).*)" ],
};
