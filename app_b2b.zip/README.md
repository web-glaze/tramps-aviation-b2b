# Tramps Aviation — B2B Agent Portal

This is the **B2B-only** project extracted from the original mixed `tramps-aviation-frontend` repo.

## What's here

- Agent login, registration & KYC
- Dashboard with stats and charts
- Flight / Hotel / Insurance / Series-Fare booking
- Wallet, Commission, Reports
- Agent Profile & Help

## What's NOT here (intentionally removed)

- B2C homepage, search, my-trips
- B2C login/register
- Consumer-facing navbar (`B2CNavbar`, `CommonHeader`)
- Home carousels (PopularFlights, PopularCities, etc.)

## Getting Started

```bash
npm install
npm run dev        # runs on http://localhost:3001
```

## Environment Variables

Copy `.env.example` → `.env.local` and fill in:

```
NEXT_PUBLIC_API_URL=https://api.tramps-aviation.com
NEXT_PUBLIC_APP_ENV=development
```

## Deploy

```bash
npm run build
npm run start      # production on port 3001
```

For Vercel / Railway / Render: set root directory to `tramps-aviation-b2b` and build command `npm run build`.

## Route Structure

```
/                     → redirects to /b2b/login or /b2b/dashboard
/b2b/login            → Agent login
/b2b/register         → Agent registration
/b2b/kyc              → KYC verification
/b2b/dashboard        → Main dashboard (protected)
/b2b/flights          → Flight search & booking (protected)
/b2b/hotels           → Hotel search & booking (protected)
/b2b/insurance        → Insurance (protected)
/b2b/series-fare      → Series fares (protected)
/b2b/bookings         → All bookings (protected)
/b2b/wallet           → Wallet management (protected)
/b2b/commission       → Commission breakdown (protected)
/b2b/reports          → Reports (protected)
/b2b/profile          → Agent profile (protected)
/b2b/help             → Help & support (protected)
```
